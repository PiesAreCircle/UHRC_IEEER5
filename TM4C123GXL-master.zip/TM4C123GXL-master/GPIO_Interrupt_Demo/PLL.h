#ifndef _PLL_H_
#define _PLL_H_

// configure the system to get its clock from the PLL
void PLL_Init_50MHz(void);
#endif
